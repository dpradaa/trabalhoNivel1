let users = JSON.parse(localStorage.getItem("users")) || [];
let currentPage = 1;
const usersPerPage = 5;


function renderUsers() {
    const userList = document.getElementById("userList");
    const pageNumber = document.getElementById("pageNumber");
    
 
    const search = document.getElementById("search").value.toLowerCase();
    const filteredUsers = users.filter(user =>
        user.nome.toLowerCase().includes(search) || user.email.toLowerCase().includes(search)
    );


    const startIndex = (currentPage - 1) * usersPerPage;
    const endIndex = startIndex + usersPerPage;
    const usersToShow = filteredUsers.slice(startIndex, endIndex);

    userList.innerHTML = usersToShow.map(user => `
        <tr>
            <td>${user.nome}</td>
            <td>${user.email}</td>
            <td><button class="btn btn-warning btn-sm edit-btn" onclick="editUser('${user.email}')">Editar</button></td>
        </tr>
    `).join("");

    pageNumber.textContent = currentPage;
    document.getElementById("prevPage").disabled = currentPage === 1;
    document.getElementById("nextPage").disabled = currentPage * usersPerPage >= filteredUsers.length;
}


document.getElementById("cadastroForm").addEventListener("submit", function(e) {
    e.preventDefault();

    const nome = document.getElementById("nome").value;
    const email = document.getElementById("email").value;
    const senha = document.getElementById("senha").value;

    const newUser = { nome, email, senha };
    users.push(newUser);
    localStorage.setItem("users", JSON.stringify(users));


    e.target.reset();
    renderUsers();
});


document.getElementById("prevPage").addEventListener("click", function() {
    if (currentPage > 1) {
        currentPage--;
        renderUsers();
    }
});

document.getElementById("nextPage").addEventListener("click", function() {
    if (currentPage * usersPerPage < users.length) {
        currentPage++;
        renderUsers();
    }
});


document.getElementById("search").addEventListener("input", function() {
    renderUsers();
});


function editUser(email) {
    const user = users.find(user => user.email === email);
    if (user) {
        alert(`Editando o usuário: ${user.nome}`);
       
    }
}


renderUsers();
