const express = require('express');
const fs = require('fs');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;


app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public'))); 

const usersFilePath = path.join(__dirname, 'users.json');


function readUsersFromFile() {
    if (fs.existsSync(usersFilePath)) {
        const data = fs.readFileSync(usersFilePath);
        return JSON.parse(data);
    }
    return [];
}


function writeUsersToFile(users) {
    fs.writeFileSync(usersFilePath, JSON.stringify(users, null, 2));
}


app.get('/api/users', (req, res) => {
    const users = readUsersFromFile();
    res.json(users);
});


app.post('/api/users', (req, res) => {
    const { nome, email, senha } = req.body;

    
    if (!nome || !email || !senha) {
        return res.status(400).json({ error: 'Todos os campos são obrigatórios.' });
    }

    const users = readUsersFromFile();

 
    if (users.some(user => user.email === email)) {
        return res.status(400).json({ error: 'Email já registrado.' });
    }


    const newUser = { nome, email, senha };
    users.push(newUser);
    writeUsersToFile(users);

    res.status(201).json(newUser);
});


app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});
