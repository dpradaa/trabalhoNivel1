const usersPerPage = 5;
let currentPage = 1;

function renderUsers() {
    const userList = document.getElementById("userList");
    const search = document.getElementById("search").value.toLowerCase();
    
    fetch('/api/users')
        .then(response => response.json())
        .then(users => {
            const filteredUsers = users.filter(user =>
                user.nome.toLowerCase().includes(search) || user.email.toLowerCase().includes(search)
            );

            const startIndex = (currentPage - 1) * usersPerPage;
            const endIndex = startIndex + usersPerPage;
            const usersToShow = filteredUsers.slice(startIndex, endIndex);

            userList.innerHTML = usersToShow.map(user => `
                <tr>
                    <td>${user.nome}</td>
                    <td>${user.email}</td>
                    <td><button class="btn btn-warning btn-sm" onclick="editUser('${user.email}')">Editar</button></td>
                </tr>
            `).join("");
        });
}

document.getElementById("cadastroForm").addEventListener("submit", function(e) {
    e.preventDefault();

    const nome = document.getElementById("nome").value;
    const email = document.getElementById("email").value;
    const senha = document.getElementById("senha").value;

    const newUser = { nome, email, senha };

    fetch('/api/users', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(newUser),
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            alert(data.error);
        } else {
            renderUsers();
            e.target.reset();
        }
    })
    .catch(error => console.error('Erro ao cadastrar o usuário:', error));
});

function editUser(email) {
    alert(`Editando o usuário: ${email}`);
}

renderUsers();
